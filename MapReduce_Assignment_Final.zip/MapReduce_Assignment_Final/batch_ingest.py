import os
import happybase
from datetime import datetime
#create connection
connection = happybase.Connection('localhost')
#open connection to perform operations
def open_connection():
    connection.open()
#close the opened connection
def close_connection():
    connection.close()
#get the pointer to a table
def get_table(name):
    open_connection()
    table = connection.table(name)
    close_connection()
    return table
#batch insert data
def batch_insert_data(filename):
    print("Starting batch insert")
    file = open(filename, "r")
    table_name = 'hbase_yellow_taxi_trip_record'
    table = get_table(table_name)
    open_connection()
    start_time = datetime.now()
    i = 0
    line_num = 0
    with table.batch(batch_size=30000) as b:
        print('inside with:')
        for line in file:
            
            if line_num % 1000 == 0:
                print(line_num, 'Lines loaded')
            if i!=0:
                temp = line.strip().split(",")
                b.put(temp[0]+":"+temp[1]+":"+temp[2] , 
                { 'Trip_Attributes:VendorID':temp[0] ,'Trip_Attributes:tpep_pickup_datetime':temp[1] ,
                 'Trip_Attributes:tpep_dropoff_datetime':temp[2] ,
                  'Trip_Attributes:passenger_count':temp[3] ,'Trip_Attributes:trip_distance':temp[4] ,
                 'Trip_Attributes:RatecodeID':temp[5] ,'Trip_Attributes:store_and_fwd_flag':temp[6] ,
                 'Trip_Attributes:PULocationID':temp[7] ,'Trip_Attributes:DOLocationID':temp[8] ,
                 'Trip_Attributes:payment_type':temp[9] ,'Trip_Attributes:fare_amount':temp[10] ,
                 'Trip_Attributes:extra':temp[11] ,'Trip_Attributes:mta_tax':temp[12] ,
                 'Trip_Attributes:tip_amount':temp[13] ,'Trip_Attributes:tolls_amount':temp[14] ,
                 'Trip_Attributes:improvement_surcharge':temp[15] ,'Trip_Attributes:total_amount':temp[16] ,
                 'Trip_Attributes:congestion_surcharge':temp[17] ,'Trip_Attributes:airport_fee':temp[18]
                })
            i+=1
            line_num+= 1
        file.close()
        print("batch insert done line_num :",line_num)
        
        print(" ---------------------------------------------------------------------------------------- ")
        print(" ---------------------------------Completion of insertion ------------------------------- ")
        print(" ----------------------------------- File: ",filename,"---------------------------------- ")
        print(" ---------------------- Run time: ",datetime.now()-start_time," ------------------------- ")
        print(" ---------------------------------------------------------------------------------------- ")
        close_connection()
                

for filename in os.listdir() :
     if filename.startswith("yellow_tripdata_"):
        print('Loading data in '+filename)
        batch_insert_data(filename)