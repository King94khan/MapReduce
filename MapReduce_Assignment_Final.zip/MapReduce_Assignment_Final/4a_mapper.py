import sys

for line in sys.stdin:
    line = line.strip()
    line = line.split(',')

# Skip the header row
    if line[0] != "VendorID":
        vendorid = line[0]
        total_amount = line[-3]

        print('%s\t%s' % (vendorid, total_amount))
